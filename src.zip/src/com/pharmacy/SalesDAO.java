package com.pharmacy;

public class SalesDAO {

}
