package com.pharmacy.main;

import java.sql.Date;
import java.util.Scanner;

import com.pharmacy.dto.MedicineDTO;
import com.pharmacy.dto.SupplierDTO;
import com.pharmacy.service.MedicineService;
import com.pharmacy.service.SupplierService;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MedicineService medicineService = new MedicineService();
        SupplierService supplierService = new SupplierService();

        while (true) {
            System.out.println("\n--- PHARMACY MANAGEMENT SYSTEM ---");
            System.out.println("1. Add Supplier");
            System.out.println("2. Add Medicine");
            System.out.println("3. View Medicines");
            System.out.println("4. View Expired Medicines");
            System.out.println("5. Delete Medicine");
            System.out.println("6. Exit");

            System.out.print("Enter choice: ");
            int ch = sc.nextInt();

            switch (ch) {

                case 1:
                    System.out.print("Name Contact Email Address: ");
                    supplierService.addSupplier(
                        new SupplierDTO(0, sc.next(), sc.next(), sc.next(), sc.next())
                    );
                    System.out.println("Supplier added");
                    break;

                case 2:
                    System.out.print("Name Category Price Qty Expiry(yyyy-mm-dd) SupplierId: ");
                    medicineService.addMedicine(
                        new MedicineDTO(0, sc.next(), sc.next(),
                                sc.nextDouble(), sc.nextInt(),
                                Date.valueOf(sc.next()), sc.nextInt())
                    );
                    System.out.println("Medicine added");
                    break;

                case 3:
                    medicineService.getAllMedicines().forEach(System.out::println);
                    break;

                case 4:
                    medicineService.getExpiredMedicines().forEach(System.out::println);
                    break;
                    
                case 5:
                    System.out.print("Enter Medicine ID to delete: ");
                    int delId = sc.nextInt();

                    if (medicineService.deleteMedicine(delId)) {
                        System.out.println("Medicine deleted successfully");
                    } else {
                        System.out.println("Medicine not found");
                    }
                    break;

                case 6:
                    System.exit(0);
            }
        }
    }
}