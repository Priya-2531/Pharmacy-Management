package com.pharmacy.service;

import java.util.List;
import com.pharmacy.dao.SalesDAO;
import com.pharmacy.dao.SalesDAOImpl;
import com.pharmacy.dto.SalesDTO;

public class SalesService {

    private SalesDAO dao = new SalesDAOImpl();

    public void addSale(SalesDTO s) {
        dao.addSale(s);
    }

    public List<SalesDTO> getAllSales() {
        return dao.getAllSales();
    }
}