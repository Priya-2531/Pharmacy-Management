package com.pharmacy.service;

import java.util.List;
import com.pharmacy.dao.MedicineDAO;
import com.pharmacy.dao.MedicineDAOImpl;
import com.pharmacy.dto.MedicineDTO;

public class MedicineService {

    private MedicineDAO dao = new MedicineDAOImpl();

    public void addMedicine(MedicineDTO m) {
        dao.addMedicine(m);
    }

    public List<MedicineDTO> getAllMedicines() {
        return dao.getAllMedicines();
    }

    public List<MedicineDTO> getExpiredMedicines() {
        return dao.getExpiredMedicines();
    }

    public MedicineDTO getMedicineById(int id) {
        return dao.getMedicineById(id);
    }

    public boolean updateStock(int id, int qty) {
        return dao.updateStock(id, qty);
    }
        
        public boolean deleteMedicine(int id) {
            return dao.deleteMedicine(id);
        
    }
}