package com.pharmacy.service;

import java.util.List;
import com.pharmacy.dao.SupplierDAO;
import com.pharmacy.dao.SupplierDAOImpl;
import com.pharmacy.dto.SupplierDTO;

public class SupplierService {

    private SupplierDAO dao = new SupplierDAOImpl();

    public void addSupplier(SupplierDTO s) {
        dao.addSupplier(s);
    }

    public List<SupplierDTO> getAllSuppliers() {
        return dao.getAllSuppliers();
    }
}