
	package com.pharmacy.dao;

	import java.util.List;
	import com.pharmacy.dto.SupplierDTO;

	public interface SupplierDAO {

	    void addSupplier(SupplierDTO supplier);

	    List<SupplierDTO> getAllSuppliers();

	    SupplierDTO getSupplierById(int supplierId);
	}

