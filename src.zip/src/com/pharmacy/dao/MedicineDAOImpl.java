package com.pharmacy.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.pharmacy.dto.MedicineDTO;
import com.pharmacy.util.DBConnection;

public class MedicineDAOImpl implements MedicineDAO {

    @Override
    public void addMedicine(MedicineDTO m) {
        String sql = "INSERT INTO medicines "
                   + "(name, category, price, quantity, expiry_date, supplier_id) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, m.getName());
            ps.setString(2, m.getCategory());
            ps.setDouble(3, m.getPrice());
            ps.setInt(4, m.getQuantity());
            ps.setDate(5, m.getExpiryDate());
            ps.setInt(6, m.getSupplierId());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<MedicineDTO> getAllMedicines() {
        List<MedicineDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM medicines";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MedicineDTO m = new MedicineDTO();
                m.setId(rs.getInt("id"));
                m.setName(rs.getString("name"));
                m.setCategory(rs.getString("category"));
                m.setPrice(rs.getDouble("price"));
                m.setQuantity(rs.getInt("quantity"));
                m.setExpiryDate(rs.getDate("expiry_date"));
                m.setSupplierId(rs.getInt("supplier_id"));
                list.add(m);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<MedicineDTO> getExpiredMedicines() {
        List<MedicineDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM medicines WHERE expiry_date < CURDATE()";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MedicineDTO m = new MedicineDTO();
                m.setId(rs.getInt("id"));
                m.setName(rs.getString("name"));
                m.setCategory(rs.getString("category"));
                m.setPrice(rs.getDouble("price"));
                m.setQuantity(rs.getInt("quantity"));
                m.setExpiryDate(rs.getDate("expiry_date"));
                m.setSupplierId(rs.getInt("supplier_id"));
                list.add(m);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean updateStock(int medicineId, int quantity) {
        String sql = "UPDATE medicines SET quantity = quantity - ? WHERE id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, quantity);
            ps.setInt(2, medicineId);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public MedicineDTO getMedicineById(int medicineId) {
        String sql = "SELECT * FROM medicines WHERE id = ?";
        MedicineDTO m = null;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, medicineId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                m = new MedicineDTO();
                m.setId(rs.getInt("id"));
                m.setName(rs.getString("name"));
                m.setCategory(rs.getString("category"));
                m.setPrice(rs.getDouble("price"));
                m.setQuantity(rs.getInt("quantity"));
                m.setExpiryDate(rs.getDate("expiry_date"));
                m.setSupplierId(rs.getInt("supplier_id"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return m;
    }
        public boolean deleteMedicine(int medicineId) {

            String sql = "DELETE FROM medicines WHERE id = ?";

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, medicineId);

                return ps.executeUpdate() > 0;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        
    }
}