
	package com.pharmacy.dao;

	import java.util.List;
	import com.pharmacy.dto.SalesDTO;

	public interface SalesDAO {

	    void addSale(SalesDTO sale);

	    List<SalesDTO> getAllSales();
	}

