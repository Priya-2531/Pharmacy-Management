
	package com.pharmacy.dao;

	import java.util.List;
	import com.pharmacy.dto.MedicineDTO;

	public interface MedicineDAO {

	    void addMedicine(MedicineDTO medicine);

	    List<MedicineDTO> getAllMedicines();

	    List<MedicineDTO> getExpiredMedicines();

	    boolean updateStock(int medicineId, int quantity);

	    MedicineDTO getMedicineById(int medicineId);
	    
	    boolean deleteMedicine(int medicineID);
	}
