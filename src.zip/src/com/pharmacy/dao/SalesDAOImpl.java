package com.pharmacy.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.pharmacy.dto.SalesDTO;
import com.pharmacy.util.DBConnection;

public class SalesDAOImpl implements SalesDAO {

    @Override
    public void addSale(SalesDTO sale) {
        String sql = "INSERT INTO sales (medicine_id, quantity, total_price) VALUES (?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, sale.getMedicineId());
            ps.setInt(2, sale.getQuantity());
            ps.setDouble(3, sale.getTotalPrice());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<SalesDTO> getAllSales() {
        List<SalesDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM sales";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                SalesDTO s = new SalesDTO();
                s.setSaleId(rs.getInt("sale_id"));
                s.setMedicineId(rs.getInt("medicine_id"));
                s.setQuantity(rs.getInt("quantity"));
                s.setTotalPrice(rs.getDouble("total_price"));
                s.setSaleDate(rs.getTimestamp("sale_date"));
                list.add(s);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}