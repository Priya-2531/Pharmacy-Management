package com.pharmacy.dto;

import java.sql.Timestamp;

public class SalesDTO {

    private int saleId;
    private int medicineId;
    private int quantity;
    private double totalPrice;
    private Timestamp saleDate;

    // No-argument constructor
    public SalesDTO() {}

    // Parameterized constructor
    public SalesDTO(int saleId, int medicineId,
                    int quantity, double totalPrice,
                    Timestamp saleDate) {
        this.saleId = saleId;
        this.medicineId = medicineId;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
        this.saleDate = saleDate;
    }

    // Getters and Setters
    public int getSaleId() {
        return saleId;
    }

    public void setSaleId(int saleId) {
        this.saleId = saleId;
    }

    public int getMedicineId() {
        return medicineId;
    }

    public void setMedicineId(int medicineId) {
        this.medicineId = medicineId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Timestamp getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(Timestamp saleDate) {
        this.saleDate = saleDate;
    }
}