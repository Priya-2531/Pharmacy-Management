package com.pharmacy.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.pharmacy.dto.MedicineDTO;
import com.pharmacy.dto.SupplierDTO;
import com.pharmacy.service.MedicineService;
import com.pharmacy.service.SupplierService;

import java.awt.*;
import java.sql.Date;
import java.util.List;

public class MedicineUI {

    private static JTable table;
    private static DefaultTableModel model;

    private static JTextField nameField, priceField, quantityField, expiryField;
    private static JComboBox<String> categoryBox, supplierBox;

    private static JFrame frame;

    public static void main(String[] args) {

        frame = new JFrame("Pharmacy Management System");

        // ===== HEADER =====
        JLabel title = new JLabel("PHARMACY MANAGEMENT SYSTEM", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ===== FORM PANEL =====
        JPanel form = new JPanel(new GridLayout(6, 2, 10, 10));
        form.setBorder(BorderFactory.createTitledBorder("Medicine Details"));

        nameField = new JTextField();
        priceField = new JTextField();
        quantityField = new JTextField();
        expiryField = new JTextField();

        String categories[] = {"Tablet", "Capsule", "Syrup", "Injection"};
        categoryBox = new JComboBox<>(categories);

        supplierBox = new JComboBox<>();

        List<SupplierDTO> suppliers = new SupplierService().getAllSuppliers();
        for (SupplierDTO s : suppliers) {
            supplierBox.addItem(s.getSupplierId() + " - " + s.getSupplierName());
        }

        form.add(new JLabel("Name:")); form.add(nameField);
        form.add(new JLabel("Category:")); form.add(categoryBox);
        form.add(new JLabel("Price:")); form.add(priceField);
        form.add(new JLabel("Quantity:")); form.add(quantityField);
        form.add(new JLabel("Expiry:")); form.add(expiryField);
        form.add(new JLabel("Supplier:")); form.add(supplierBox);

        // ===== BUTTON PANEL =====
        JPanel buttons = new JPanel();

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton refreshBtn = new JButton("Refresh");

        // Styling buttons
        addBtn.setBackground(Color.GREEN);
        updateBtn.setBackground(Color.ORANGE);
        deleteBtn.setBackground(Color.RED);
        refreshBtn.setBackground(Color.CYAN);

        buttons.add(addBtn);
        buttons.add(updateBtn);
        buttons.add(deleteBtn);
        buttons.add(refreshBtn);

        // ===== TABLE =====
        model = new DefaultTableModel();
        table = new JTable(model);

        model.setColumnIdentifiers(new String[]{
                "ID", "Name", "Category", "Price", "Qty", "Expiry", "SupplierID"
        });

        JScrollPane scroll = new JScrollPane(table);

        // ===== ADD ACTION =====
        addBtn.addActionListener(e -> {
            try {
                MedicineDTO dto = new MedicineDTO();

                dto.setName(nameField.getText());
                dto.setCategory((String) categoryBox.getSelectedItem());
                dto.setPrice(Double.parseDouble(priceField.getText()));
                dto.setQuantity(Integer.parseInt(quantityField.getText()));
                dto.setExpiryDate(Date.valueOf(expiryField.getText()));

                String selected = (String) supplierBox.getSelectedItem();
                int supplierId = Integer.parseInt(selected.split(" - ")[0]);
                dto.setSupplierId(supplierId);

                new MedicineService().addMedicine(dto);

                JOptionPane.showMessageDialog(frame, "Added!");
                loadTable();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error!");
            }
        });

        // ===== REFRESH =====
        refreshBtn.addActionListener(e -> loadTable());

        // ===== TABLE CLICK =====
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = table.getSelectedRow();

                nameField.setText(model.getValueAt(row, 1).toString());
                categoryBox.setSelectedItem(model.getValueAt(row, 2).toString());
                priceField.setText(model.getValueAt(row, 3).toString());
                quantityField.setText(model.getValueAt(row, 4).toString());
                expiryField.setText(model.getValueAt(row, 5).toString());
            }
        });

        // ===== UPDATE =====
        updateBtn.addActionListener(e -> {
            try {
                int row = table.getSelectedRow();
                int id = Integer.parseInt(model.getValueAt(row, 0).toString());

                MedicineDTO dto = new MedicineDTO();
                dto.setId(id);
                dto.setName(nameField.getText());
                dto.setCategory((String) categoryBox.getSelectedItem());
                dto.setPrice(Double.parseDouble(priceField.getText()));
                dto.setQuantity(Integer.parseInt(quantityField.getText()));
                dto.setExpiryDate(Date.valueOf(expiryField.getText()));

                String selected = (String) supplierBox.getSelectedItem();
                int supplierId = Integer.parseInt(selected.split(" - ")[0]);
                dto.setSupplierId(supplierId);

                new MedicineService().updateMedicine(dto);

                JOptionPane.showMessageDialog(frame, "Updated!");
                loadTable();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error!");
            }
        });

        // ===== DELETE =====
        deleteBtn.addActionListener(e -> {
            try {
                int row = table.getSelectedRow();
                int id = Integer.parseInt(model.getValueAt(row, 0).toString());

                new MedicineService().deleteMedicine(id);

                JOptionPane.showMessageDialog(frame, "Deleted!");
                loadTable();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error!");
            }
        });

        // ===== LAYOUT =====
        frame.setLayout(new BorderLayout());
        frame.add(title, BorderLayout.NORTH);
        frame.add(form, BorderLayout.WEST);
        frame.add(scroll, BorderLayout.CENTER);
        frame.add(buttons, BorderLayout.SOUTH);

        frame.setSize(900, 500);
        frame.setLocationRelativeTo(null); // center screen
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        loadTable();
    }

    private static void loadTable() {
        model.setRowCount(0);

        List<MedicineDTO> list = new MedicineService().getAllMedicines();

        for (MedicineDTO m : list) {
            model.addRow(new Object[]{
                    m.getId(),
                    m.getName(),
                    m.getCategory(),
                    m.getPrice(),
                    m.getQuantity(),
                    m.getExpiryDate(),
                    m.getSupplierId()
            });
        }
    }
}